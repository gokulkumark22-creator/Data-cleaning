/* =========================================================
   DataClean Insights — app.js
   All data handling runs client-side. No backend required.
   ========================================================= */
(function(){
  "use strict";

  /* ---------------- state ---------------- */
  const state = {
    fileName: null,
    fileSize: 0,
    rawRows: [],        // array of objects
    rawColumns: [],      // array of strings
    cleanedRows: null,
    cleanedColumns: null,
    columnTypes: {},     // colName -> 'numeric' | 'text' | 'date'
    missingCount: 0,
    duplicateCount: 0,
    outlierCount: 0,
    outlierRowIdx: new Set(),
    renameMap: {},        // original -> new
    includedColumns: new Set(),
    charts: {},
    activeFilter: { col: "", val: "" }
  };

  /* ---------------- helpers ---------------- */
  const $ = (sel, ctx) => (ctx || document).querySelector(sel);
  const $$ = (sel, ctx) => Array.from((ctx || document).querySelectorAll(sel));
  const fmtNum = n => (n === null || n === undefined || Number.isNaN(n)) ? "—" : Number(n).toLocaleString(undefined, {maximumFractionDigits: 2});
  const isBlank = v => v === null || v === undefined || (typeof v === "string" && v.trim() === "");
  const isNumericVal = v => v !== "" && v !== null && !isNaN(v) && typeof v !== "boolean";

  function currentColumns(){ return state.cleanedColumns || state.rawColumns; }
  function currentRows(){ return state.cleanedRows || state.rawRows; }

  /* =========================================================
     THEME
     ========================================================= */
  function toggleTheme(){
    const dark = document.body.classList.contains("theme-dark");
    document.body.classList.toggle("theme-dark", !dark);
    document.body.classList.toggle("theme-light", dark);
    localStorage.setItem("dci-theme", dark ? "light" : "dark");
    Object.values(state.charts).forEach(c => c && c.update());
  }
  (function initTheme(){
    const saved = localStorage.getItem("dci-theme");
    if (saved === "light"){
      document.body.classList.remove("theme-dark");
      document.body.classList.add("theme-light");
    }
  })();
  $("#theme-toggle-landing").addEventListener("click", toggleTheme);
  $("#theme-toggle").addEventListener("click", toggleTheme);

  /* =========================================================
     NAVIGATION: landing -> app, sidebar routing
     ========================================================= */
  $("#get-started-btn").addEventListener("click", () => {
    $("#landing").classList.add("hidden");
    $("#app").classList.remove("hidden");
    goToView("upload");
  });

  function goToView(view){
    $$(".nav-item").forEach(b => b.classList.toggle("active", b.dataset.view === view));
    $$(".view").forEach(v => v.classList.remove("active"));
    $("#view-" + view).classList.add("active");
    const titles = {
      home: "Home", upload: "Upload Dataset", cleaning: "Data Cleaning",
      analysis: "Data Analysis", dashboard: "Visualization Dashboard",
      insights: "Insights", about: "About Project"
    };
    $("#view-title").textContent = titles[view] || view;
    closeSidebar();
    if (view === "dashboard" && currentRows().length) renderChart();
    if (view === "analysis" && currentRows().length) renderCorrHeatmap();
  }
  $$(".nav-item").forEach(btn => btn.addEventListener("click", () => goToView(btn.dataset.view)));
  $$("[data-goto]").forEach(el => el.addEventListener("click", () => goToView(el.dataset.goto)));

  function closeSidebar(){
    $("#sidebar").classList.remove("open");
    $("#sidebar-scrim").classList.remove("show");
  }
  $("#menu-toggle").addEventListener("click", () => {
    $("#sidebar").classList.toggle("open");
    $("#sidebar-scrim").classList.toggle("show");
  });
  $("#sidebar-scrim").addEventListener("click", closeSidebar);

  /* =========================================================
     FILE UPLOAD
     ========================================================= */
  const dropzone = $("#dropzone");
  const fileInput = $("#file-input");

  ["dragenter","dragover"].forEach(evt => dropzone.addEventListener(evt, e => {
    e.preventDefault(); dropzone.classList.add("dragover");
  }));
  ["dragleave","drop"].forEach(evt => dropzone.addEventListener(evt, e => {
    e.preventDefault(); dropzone.classList.remove("dragover");
  }));
  dropzone.addEventListener("drop", e => {
    const file = e.dataTransfer.files[0];
    if (file) handleFile(file);
  });
  fileInput.addEventListener("change", e => {
    const file = e.target.files[0];
    if (file) handleFile(file);
  });

  function handleFile(file){
    state.fileName = file.name;
    state.fileSize = file.size;
    $("#upload-status").textContent = "Reading " + file.name + " …";

    const ext = file.name.split(".").pop().toLowerCase();
    if (ext === "csv"){
      Papa.parse(file, {
        header: true, skipEmptyLines: true, dynamicTyping: false,
        complete: res => ingestData(res.data, res.meta.fields || Object.keys(res.data[0] || {}))
      });
    } else if (ext === "xlsx" || ext === "xls"){
      const reader = new FileReader();
      reader.onload = e => {
        const wb = XLSX.read(e.target.result, {type:"array"});
        const sheet = wb.Sheets[wb.SheetNames[0]];
        const json = XLSX.utils.sheet_to_json(sheet, {defval:""});
        const cols = json.length ? Object.keys(json[0]) : [];
        ingestData(json, cols);
      };
      reader.readAsArrayBuffer(file);
    } else {
      $("#upload-status").textContent = "Unsupported file type. Please upload a .csv or .xlsx file.";
    }
  }

  function ingestData(rows, columns){
    // normalize values to strings/numbers, coerce numeric-looking strings
    rows.forEach(r => {
      columns.forEach(c => {
        let v = r[c];
        if (typeof v === "string") v = v.trim();
        if (v !== "" && v !== null && v !== undefined && !isNaN(v) && v !== true && v !== false){
          r[c] = v === "" ? "" : (v === null ? null : Number(v));
        } else {
          r[c] = v;
        }
      });
    });

    state.rawRows = rows;
    state.rawColumns = columns;
    state.cleanedRows = null;
    state.cleanedColumns = null;
    state.includedColumns = new Set(columns);
    state.renameMap = {};
    detectColumnTypes(rows, columns);
    computeBaselineStats();

    $("#upload-status").textContent = "Loaded " + file_sizeLabel(state.fileSize) + " · " + rows.length + " rows × " + columns.length + " columns.";
    $("#sum-filename").textContent = state.fileName;
    $("#sum-rows").textContent = rows.length.toLocaleString();
    $("#sum-cols").textContent = columns.length;
    $("#sum-size").textContent = file_sizeLabel(state.fileSize);
    $("#dataset-summary-panel").classList.remove("hidden");
    $("#raw-preview-panel").classList.remove("hidden");
    $("#sidebar-dataset-name").textContent = state.fileName;

    renderTable($("#raw-preview-table"), rows.slice(0,15), columns);
    buildCleaningTools();
    $("#cleaning-empty").classList.add("hidden");
    $("#cleaning-content").classList.remove("hidden");

    updateHomeKpis();
    populateDashboardControls();
    renderDashboardEmptyToggle(true);
    renderAnalysisEmptyToggle(true);
    renderInsightsEmptyToggle(true);

    runAnalysis();
    runInsights();
  }

  function file_sizeLabel(bytes){
    if (!bytes) return "—";
    if (bytes < 1024) return bytes + " B";
    if (bytes < 1024*1024) return (bytes/1024).toFixed(1) + " KB";
    return (bytes/(1024*1024)).toFixed(2) + " MB";
  }

  function detectColumnTypes(rows, columns){
    state.columnTypes = {};
    columns.forEach(col => {
      let numericCount = 0, total = 0;
      for (let i=0; i<Math.min(rows.length, 200); i++){
        const v = rows[i][col];
        if (isBlank(v)) continue;
        total++;
        if (typeof v === "number") numericCount++;
      }
      state.columnTypes[col] = (total > 0 && numericCount/total > 0.8) ? "numeric" : "text";
    });
  }

  function computeBaselineStats(){
    let missing = 0;
    state.rawRows.forEach(r => state.rawColumns.forEach(c => { if (isBlank(r[c])) missing++; }));
    state.missingCount = missing;

    const seen = new Set();
    let dupes = 0;
    state.rawRows.forEach(r => {
      const key = JSON.stringify(state.rawColumns.map(c => r[c]));
      if (seen.has(key)) dupes++; else seen.add(key);
    });
    state.duplicateCount = dupes;

    state.outlierRowIdx = new Set();
    let outliers = 0;
    state.rawColumns.forEach(col => {
      if (state.columnTypes[col] !== "numeric") return;
      const vals = state.rawRows.map(r=>r[col]).filter(isNumericVal).sort((a,b)=>a-b);
      if (vals.length < 4) return;
      const q1 = quantile(vals, 0.25), q3 = quantile(vals, 0.75);
      const iqr = q3 - q1;
      const lo = q1 - 1.5*iqr, hi = q3 + 1.5*iqr;
      state.rawRows.forEach((r, idx) => {
        const v = r[col];
        if (isNumericVal(v) && (v < lo || v > hi)){
          outliers++;
          state.outlierRowIdx.add(idx);
        }
      });
    });
    state.outlierCount = outliers;
  }

  function quantile(sortedArr, q){
    const pos = (sortedArr.length - 1) * q;
    const base = Math.floor(pos), rest = pos - base;
    if (sortedArr[base+1] !== undefined) return sortedArr[base] + rest*(sortedArr[base+1]-sortedArr[base]);
    return sortedArr[base];
  }

  /* =========================================================
     TABLE RENDERING
     ========================================================= */
  function renderTable(tableEl, rows, columns, opts){
    opts = opts || {};
    const thead = "<thead><tr>" + columns.map(c => `<th>${escapeHtml(opts.labels ? opts.labels[c]||c : c)}</th>`).join("") + "</tr></thead>";
    const tbody = "<tbody>" + rows.map((r, i) => {
      const cells = columns.map(c => {
        const v = r[c];
        const missing = isBlank(v);
        const outlier = opts.outlierIdx && opts.outlierIdx.has(opts.baseIdx ? opts.baseIdx[i] : i);
        const cls = missing ? "cell-missing" : (outlier ? "cell-outlier" : "");
        const display = missing ? "∅ missing" : escapeHtml(String(v));
        return `<td class="${cls}">${display}</td>`;
      }).join("");
      return "<tr>" + cells + "</tr>";
    }).join("") + "</tbody>";
    tableEl.innerHTML = thead + tbody;
  }

  function escapeHtml(s){
    return s.replace(/[&<>"']/g, m => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[m]));
  }

  /* =========================================================
     HOME KPIs
     ========================================================= */
  function updateHomeKpis(){
    $("#home-kpi-rows").textContent = state.rawRows.length.toLocaleString();
    $("#home-kpi-cols").textContent = state.rawColumns.length;
    $("#home-kpi-missing").textContent = state.missingCount.toLocaleString();
    $("#home-kpi-dupes").textContent = state.duplicateCount.toLocaleString();
  }

  /* =========================================================
     CLEANING MODULE
     ========================================================= */
  function buildCleaningTools(){
    $("#stat-missing").textContent = state.missingCount.toLocaleString();
    $("#stat-dupes").textContent = state.duplicateCount.toLocaleString();
    $("#stat-outliers").textContent = state.outlierCount.toLocaleString();
    $("#stat-remaining").textContent = state.rawRows.length.toLocaleString();

    const renameList = $("#rename-list");
    renameList.innerHTML = "";
    state.rawColumns.forEach(col => {
      const row = document.createElement("div");
      row.className = "rename-row";
      row.innerHTML = `<input type="text" data-col="${escapeHtml(col)}" value="${escapeHtml(col)}" />`;
      renameList.appendChild(row);
    });

    const colToggle = $("#column-toggle-list");
    colToggle.innerHTML = "";
    state.rawColumns.forEach(col => {
      const row = document.createElement("label");
      row.className = "col-toggle-row";
      row.innerHTML = `<input type="checkbox" data-col="${escapeHtml(col)}" checked /><span>${escapeHtml(col)}</span>`;
      colToggle.appendChild(row);
    });

    $("#cleaning-summary-panel").classList.add("hidden");
    $("#cleaned-preview-panel").classList.add("hidden");
  }

  $("#run-cleaning-btn").addEventListener("click", runCleaning);
  $("#reset-cleaning-btn").addEventListener("click", () => {
    $("#opt-missing").value = "none";
    $("#opt-dupes").checked = true;
    $("#opt-outliers").value = "flag";
    $("#opt-formats").checked = true;
    buildCleaningTools();
  });

  function runCleaning(){
    const missingMode = $("#opt-missing").value;
    const removeDupes = $("#opt-dupes").checked;
    const outlierMode = $("#opt-outliers").value;
    const fixFormats = $("#opt-formats").checked;

    const includedCols = $$("#column-toggle-list input:checked").map(i => i.dataset.col);
    const renameMap = {};
    $$("#rename-list input").forEach(inp => { renameMap[inp.dataset.col] = inp.value.trim() || inp.dataset.col; });

    let rows = state.rawRows.map(r => ({...r}));
    const summary = [];

    // format fixing: trim strings, normalize numbers
    if (fixFormats){
      rows.forEach(r => includedCols.forEach(c => {
        if (typeof r[c] === "string") r[c] = r[c].trim();
      }));
      summary.push("Trimmed whitespace and normalized text/number formats across all columns.");
    }

    // missing values
    if (missingMode === "drop"){
      const before = rows.length;
      rows = rows.filter(r => includedCols.every(c => !isBlank(r[c])));
      summary.push(`Dropped ${before - rows.length} rows containing missing values.`);
    } else if (missingMode !== "none"){
      includedCols.forEach(col => {
        const type = state.columnTypes[col];
        if (type === "numeric" && (missingMode === "mean" || missingMode === "median")){
          const vals = rows.map(r=>r[col]).filter(isNumericVal);
          if (!vals.length) return;
          const fill = missingMode === "mean" ? (vals.reduce((a,b)=>a+b,0)/vals.length) : quantile([...vals].sort((a,b)=>a-b), 0.5);
          rows.forEach(r => { if (isBlank(r[col])) r[col] = Math.round(fill*100)/100; });
        } else if (missingMode === "mode"){
          const freq = {};
          rows.forEach(r => { if (!isBlank(r[col])) freq[r[col]] = (freq[r[col]]||0)+1; });
          const modeVal = Object.keys(freq).sort((a,b)=>freq[b]-freq[a])[0];
          if (modeVal !== undefined) rows.forEach(r => { if (isBlank(r[col])) r[col] = state.columnTypes[col]==="numeric" ? Number(modeVal) : modeVal; });
        } else if (missingMode === "zero"){
          rows.forEach(r => { if (isBlank(r[col])) r[col] = type === "numeric" ? 0 : "Unknown"; });
        }
      });
      summary.push(`Filled missing values in ${includedCols.length} columns using strategy: "${$("#opt-missing").selectedOptions[0].text}".`);
    } else {
      summary.push("Missing values left as-is.");
    }

    // duplicates
    if (removeDupes){
      const seen = new Set(); const deduped = [];
      rows.forEach(r => {
        const key = JSON.stringify(includedCols.map(c=>r[c]));
        if (!seen.has(key)){ seen.add(key); deduped.push(r); }
      });
      summary.push(`Removed ${rows.length - deduped.length} duplicate rows.`);
      rows = deduped;
    } else {
      summary.push("Duplicate rows were kept.");
    }

    // outliers
    let outlierFlagged = 0;
    if (outlierMode !== "none"){
      const outlierIdx = new Set();
      includedCols.forEach(col => {
        if (state.columnTypes[col] !== "numeric") return;
        const vals = rows.map(r=>r[col]).filter(isNumericVal).sort((a,b)=>a-b);
        if (vals.length < 4) return;
        const q1=quantile(vals,0.25), q3=quantile(vals,0.75), iqr=q3-q1;
        const lo=q1-1.5*iqr, hi=q3+1.5*iqr;
        rows.forEach((r, idx) => { if (isNumericVal(r[col]) && (r[col]<lo || r[col]>hi)) outlierIdx.add(idx); });
      });
      outlierFlagged = outlierIdx.size;
      if (outlierMode === "remove"){
        rows = rows.filter((r, idx) => !outlierIdx.has(idx));
        summary.push(`Detected and removed ${outlierFlagged} rows containing outliers (IQR method).`);
      } else {
        summary.push(`Flagged ${outlierFlagged} rows containing outliers (IQR method) — rows were kept.`);
      }
    } else {
      summary.push("Outlier detection skipped.");
    }

    // rename + column removal
    const finalCols = includedCols.map(c => renameMap[c] || c);
    rows = rows.map(r => {
      const nr = {};
      includedCols.forEach(c => { nr[renameMap[c] || c] = r[c]; });
      return nr;
    });
    const removedCols = state.rawColumns.filter(c => !includedCols.includes(c));
    if (removedCols.length) summary.push(`Removed columns: ${removedCols.join(", ")}.`);
    const renamedCols = includedCols.filter(c => renameMap[c] && renameMap[c] !== c);
    if (renamedCols.length) summary.push(`Renamed ${renamedCols.length} column(s).`);

    state.cleanedRows = rows;
    state.cleanedColumns = finalCols;
    detectColumnTypes(rows, finalCols);

    $("#stat-remaining").textContent = rows.length.toLocaleString();
    $("#cleaning-summary-list").innerHTML = summary.map(s => `<li>${escapeHtml(s)}</li>`).join("");
    $("#cleaning-summary-panel").classList.remove("hidden");
    renderTable($("#cleaned-preview-table"), rows.slice(0,15), finalCols);
    $("#cleaned-preview-panel").classList.remove("hidden");

    populateDashboardControls();
    runAnalysis();
    runInsights();
    updateDashboardKpis();
    if ($("#view-dashboard").classList.contains("active")) renderChart();
  }

  /* =========================================================
     ANALYSIS MODULE
     ========================================================= */
  function renderAnalysisEmptyToggle(hasData){
    $("#analysis-empty").classList.toggle("hidden", hasData);
    $("#analysis-content").classList.toggle("hidden", !hasData);
  }

  function colStats(rows, col, type){
    if (type === "numeric"){
      const vals = rows.map(r=>r[col]).filter(isNumericVal);
      if (!vals.length) return null;
      const sorted = [...vals].sort((a,b)=>a-b);
      const mean = vals.reduce((a,b)=>a+b,0)/vals.length;
      const variance = vals.reduce((a,b)=>a+(b-mean)**2,0)/vals.length;
      const freq = {}; vals.forEach(v=>freq[v]=(freq[v]||0)+1);
      const mode = Object.keys(freq).sort((a,b)=>freq[b]-freq[a])[0];
      return {
        count: vals.length, mean, median: quantile(sorted,0.5), mode: Number(mode),
        min: sorted[0], max: sorted[sorted.length-1], std: Math.sqrt(variance)
      };
    } else {
      const vals = rows.map(r=>r[col]).filter(v=>!isBlank(v));
      const freq = {}; vals.forEach(v=>freq[v]=(freq[v]||0)+1);
      const mode = Object.keys(freq).sort((a,b)=>freq[b]-freq[a])[0];
      return { count: vals.length, unique: Object.keys(freq).length, mode };
    }
  }

  function runAnalysis(){
    const rows = currentRows(), cols = currentColumns();
    if (!rows.length){ renderAnalysisEmptyToggle(false); return; }
    renderAnalysisEmptyToggle(true);

    // stats table
    const statCols = ["Column","Type","Count","Mean","Median","Mode","Min","Max","Std Dev"];
    let rowsHtml = "";
    cols.forEach(col => {
      const type = state.columnTypes[col];
      const s = colStats(rows, col, type);
      if (!s) return;
      if (type === "numeric"){
        rowsHtml += `<tr><td>${escapeHtml(col)}</td><td>numeric</td><td>${s.count}</td><td>${fmtNum(s.mean)}</td><td>${fmtNum(s.median)}</td><td>${fmtNum(s.mode)}</td><td>${fmtNum(s.min)}</td><td>${fmtNum(s.max)}</td><td>${fmtNum(s.std)}</td></tr>`;
      } else {
        rowsHtml += `<tr><td>${escapeHtml(col)}</td><td>text</td><td>${s.count}</td><td colspan="4">${s.unique} unique values</td><td colspan="2">mode: ${escapeHtml(String(s.mode))}</td></tr>`;
      }
    });
    $("#stats-table").innerHTML = "<thead><tr>" + statCols.map(c=>`<th>${c}</th>`).join("") + "</tr></thead><tbody>" + rowsHtml + "</tbody>";

    // dtypes table
    let dtRows = cols.map(c => `<tr><td>${escapeHtml(c)}</td><td>${state.columnTypes[c]}</td></tr>`).join("");
    $("#dtypes-table").innerHTML = "<thead><tr><th>Column</th><th>Detected type</th></tr></thead><tbody>" + dtRows + "</tbody>";

    renderCorrHeatmap();
    renderAnalysisInsights();
  }

  function numericColumns(){
    return currentColumns().filter(c => state.columnTypes[c] === "numeric");
  }

  function pearson(a, b){
    const n = a.length;
    const meanA = a.reduce((x,y)=>x+y,0)/n, meanB = b.reduce((x,y)=>x+y,0)/n;
    let num=0, denA=0, denB=0;
    for (let i=0;i<n;i++){ const da=a[i]-meanA, db=b[i]-meanB; num+=da*db; denA+=da*da; denB+=db*db; }
    const den = Math.sqrt(denA*denB);
    return den === 0 ? 0 : num/den;
  }

  function renderCorrHeatmap(){
    const rows = currentRows();
    const numCols = numericColumns();
    const canvas = $("#corr-heatmap");
    if (state.charts.heatmap) { state.charts.heatmap.destroy(); state.charts.heatmap = null; }
    if (!rows.length || numCols.length < 2){
      const ctx = canvas.getContext("2d");
      ctx.clearRect(0,0,canvas.width,canvas.height);
      return;
    }
    const matrix = [];
    const colVals = numCols.map(c => rows.map(r=>r[c]).map(v => isNumericVal(v) ? v : NaN));
    const complete = colVals.map(arr => arr.filter(v=>!Number.isNaN(v)));
    for (let i=0;i<numCols.length;i++){
      for (let j=0;j<numCols.length;j++){
        // pairwise complete rows
        const pairs = [];
        for (let k=0;k<rows.length;k++){
          const vi = colVals[i][k], vj = colVals[j][k];
          if (!Number.isNaN(vi) && !Number.isNaN(vj)) pairs.push([vi,vj]);
        }
        const corr = pairs.length > 1 ? pearson(pairs.map(p=>p[0]), pairs.map(p=>p[1])) : (i===j?1:0);
        matrix.push({x: numCols[j], y: numCols[i], v: Math.round(corr*100)/100});
      }
    }
    const styles = getComputedStyle(document.body);
    state.charts.heatmap = new Chart(canvas, {
      type: "scatter",
      data: { datasets: [{
        data: matrix.map(m => ({x: numCols.indexOf(m.x), y: numCols.indexOf(m.y), v: m.v})),
        backgroundColor: ctx => {
          const v = ctx.raw.v;
          const pos = styles.getPropertyValue("--accent").trim();
          const neg = styles.getPropertyValue("--accent-2").trim();
          const alpha = Math.abs(v);
          return v >= 0 ? hexAlpha(pos, 0.15+0.7*alpha) : hexAlpha(neg, 0.15+0.7*alpha);
        },
        pointStyle: "rect",
        radius: () => Math.max(180 / numCols.length, 14)
      }]},
      options: {
        responsive:true, maintainAspectRatio:false,
        plugins: {
          legend:{display:false},
          tooltip:{ callbacks: { label: ctx => `${numCols[ctx.raw.x]} vs ${numCols[ctx.raw.y]}: r = ${ctx.raw.v}` } }
        },
        scales: {
          x: { min:-0.5, max: numCols.length-0.5, ticks:{ stepSize:1, callback: v => numCols[v]||"", color: styles.getPropertyValue("--text-muted") }, grid:{color: styles.getPropertyValue("--grid-line")} },
          y: { min:-0.5, max: numCols.length-0.5, ticks:{ stepSize:1, callback: v => numCols[v]||"", color: styles.getPropertyValue("--text-muted") }, grid:{color: styles.getPropertyValue("--grid-line")} }
        }
      },
      plugins: [{
        id:"heatlabels",
        afterDatasetsDraw(chart){
          const {ctx} = chart;
          const meta = chart.getDatasetMeta(0);
          ctx.save();
          ctx.font = "10px 'IBM Plex Mono', monospace";
          ctx.fillStyle = styles.getPropertyValue("--text");
          ctx.textAlign = "center"; ctx.textBaseline = "middle";
          meta.data.forEach((el, i) => {
            const v = chart.data.datasets[0].data[i].v;
            ctx.fillText(v.toFixed(2), el.x, el.y);
          });
          ctx.restore();
        }
      }]
    });
  }

  function hexAlpha(hex, alpha){
    hex = hex.replace("#","");
    if (hex.length === 3) hex = hex.split("").map(c=>c+c).join("");
    const r = parseInt(hex.substring(0,2),16), g = parseInt(hex.substring(2,4),16), b = parseInt(hex.substring(4,6),16);
    return `rgba(${r},${g},${b},${alpha})`;
  }

  function renderAnalysisInsights(){
    const rows = currentRows(), cols = currentColumns();
    const list = $("#analysis-insights-list");
    const items = [];
    const numCols = numericColumns();
    items.push(`Dataset currently has <strong>${rows.length.toLocaleString()}</strong> rows and <strong>${cols.length}</strong> columns (${numCols.length} numeric).`);
    if (numCols.length){
      let maxMeanCol=null, maxMean=-Infinity;
      numCols.forEach(c => { const s = colStats(rows,c,"numeric"); if (s && s.mean>maxMean){maxMean=s.mean; maxMeanCol=c;} });
      if (maxMeanCol) items.push(`"${maxMeanCol}" has the highest average value among numeric columns (${fmtNum(maxMean)}).`);
    }
    if (numCols.length >= 2){
      let best = {a:null,b:null,v:0};
      for (let i=0;i<numCols.length;i++) for (let j=i+1;j<numCols.length;j++){
        const a = rows.map(r=>r[numCols[i]]).filter(isNumericVal);
        const b = rows.map(r=>r[numCols[j]]).filter(isNumericVal);
        const n = Math.min(a.length,b.length);
        if (n<2) continue;
        const r = pearson(a.slice(0,n), b.slice(0,n));
        if (Math.abs(r) > Math.abs(best.v)) best = {a: numCols[i], b: numCols[j], v: r};
      }
      if (best.a) items.push(`Strongest correlation found between "${best.a}" and "${best.b}" (r = ${fmtNum(best.v)}).`);
    }
    list.innerHTML = items.map(i => `<li>${i}</li>`).join("");
  }

  /* =========================================================
     DASHBOARD MODULE
     ========================================================= */
  function renderDashboardEmptyToggle(hasData){
    $("#dashboard-empty").classList.toggle("hidden", hasData);
    $("#dashboard-content").classList.toggle("hidden", !hasData);
  }

  function updateDashboardKpis(){
    const rows = currentRows(), cols = currentColumns();
    $("#kpi-rows").textContent = rows.length.toLocaleString();
    $("#kpi-cols").textContent = cols.length;
    $("#kpi-missing").textContent = state.missingCount.toLocaleString();
    $("#kpi-dupes").textContent = state.duplicateCount.toLocaleString();
    $("#kpi-outliers").textContent = state.outlierCount.toLocaleString();
  }

  function populateDashboardControls(){
    renderDashboardEmptyToggle(true);
    const cols = currentColumns();
    updateDashboardKpis();

    const xSel = $("#chart-x"), ySel = $("#chart-y"), filterSel = $("#filter-col");
    [xSel, ySel, filterSel].forEach(sel => sel.innerHTML = "");
    cols.forEach(c => {
      xSel.innerHTML += `<option value="${escapeHtml(c)}">${escapeHtml(c)}</option>`;
      ySel.innerHTML += `<option value="${escapeHtml(c)}">${escapeHtml(c)}</option>`;
      filterSel.innerHTML += `<option value="${escapeHtml(c)}">${escapeHtml(c)}</option>`;
    });
    const numCols = numericColumns();
    if (numCols.length) ySel.value = numCols[0];
    populateFilterValues();
  }

  function populateFilterValues(){
    const col = $("#filter-col").value;
    const valSel = $("#filter-val");
    valSel.innerHTML = `<option value="">All values</option>`;
    if (!col) return;
    const rows = currentRows();
    const uniq = Array.from(new Set(rows.map(r=>r[col]).filter(v=>!isBlank(v)))).slice(0,200);
    uniq.forEach(v => valSel.innerHTML += `<option value="${escapeHtml(String(v))}">${escapeHtml(String(v))}</option>`);
  }
  $("#filter-col").addEventListener("change", populateFilterValues);
  $("#filter-val").addEventListener("change", () => {
    state.activeFilter = { col: $("#filter-col").value, val: $("#filter-val").value };
    renderChart();
  });
  $("#clear-filter-btn").addEventListener("click", () => {
    state.activeFilter = { col:"", val:"" };
    $("#filter-val").value = "";
    renderChart();
  });

  function filteredRows(){
    const rows = currentRows();
    if (!state.activeFilter.col || state.activeFilter.val === "") return rows;
    return rows.filter(r => String(r[state.activeFilter.col]) === state.activeFilter.val);
  }

  $("#chart-type").addEventListener("change", () => {
    const type = $("#chart-type").value;
    $("#control-y").classList.toggle("hidden", type === "pie" || type === "histogram");
    renderChart();
  });
  $("#chart-x").addEventListener("change", renderChart);
  $("#chart-y").addEventListener("change", renderChart);

  function renderChart(){
    const rows = filteredRows();
    const type = $("#chart-type").value;
    const xCol = $("#chart-x").value;
    const yCol = $("#chart-y").value;
    if (!rows.length || !xCol) return;

    const canvas = $("#main-chart");
    if (state.charts.main) { state.charts.main.destroy(); state.charts.main = null; }
    const styles = getComputedStyle(document.body);
    const accent = styles.getPropertyValue("--accent").trim();
    const accent2 = styles.getPropertyValue("--accent-2").trim();
    const textMuted = styles.getPropertyValue("--text-muted").trim();
    const grid = styles.getPropertyValue("--grid-line").trim();
    const palette = [accent, accent2, "#F87171", "#A78BFA", "#60A5FA", "#34D399", "#FB923C"];

    const commonScales = {
      x: { ticks:{color:textMuted}, grid:{color:grid} },
      y: { ticks:{color:textMuted}, grid:{color:grid} }
    };
    const commonOpts = { responsive:true, maintainAspectRatio:false, plugins:{legend:{labels:{color: styles.getPropertyValue("--text")}}} };

    if (type === "pie"){
      const freq = {};
      rows.forEach(r => { const k = String(r[xCol]); freq[k]=(freq[k]||0)+1; });
      const labels = Object.keys(freq).slice(0,12);
      state.charts.main = new Chart(canvas, {
        type:"pie",
        data:{ labels, datasets:[{ data: labels.map(l=>freq[l]), backgroundColor: labels.map((_,i)=>palette[i%palette.length]) }] },
        options: commonOpts
      });
    } else if (type === "histogram"){
      const vals = rows.map(r=>r[xCol]).filter(isNumericVal);
      if (!vals.length) return;
      const bins = 12;
      const min = Math.min(...vals), max = Math.max(...vals);
      const width = (max-min)/bins || 1;
      const counts = new Array(bins).fill(0);
      vals.forEach(v => { let idx = Math.floor((v-min)/width); if (idx>=bins) idx=bins-1; if(idx<0) idx=0; counts[idx]++; });
      const labels = counts.map((_,i)=> (min+i*width).toFixed(1) + "–" + (min+(i+1)*width).toFixed(1));
      state.charts.main = new Chart(canvas, {
        type:"bar",
        data:{ labels, datasets:[{ label: xCol + " distribution", data: counts, backgroundColor: hexAlpha(accent,0.75), borderRadius:4 }] },
        options: {...commonOpts, scales: commonScales}
      });
    } else if (type === "scatter"){
      const points = rows.map(r => ({x:r[xCol], y:r[yCol]})).filter(p => isNumericVal(p.x) && isNumericVal(p.y));
      state.charts.main = new Chart(canvas, {
        type:"scatter",
        data:{ datasets:[{ label: `${xCol} vs ${yCol}`, data: points, backgroundColor: hexAlpha(accent2,0.7) }] },
        options: {...commonOpts, scales: commonScales}
      });
    } else if (type === "line"){
      const sample = rows.slice(0, 300);
      state.charts.main = new Chart(canvas, {
        type:"line",
        data:{ labels: sample.map(r=>r[xCol]), datasets:[{ label: yCol||xCol, data: sample.map(r=>r[yCol]), borderColor: accent, backgroundColor: hexAlpha(accent,0.15), fill:true, tension:0.35, pointRadius:0 }] },
        options: {...commonOpts, scales: commonScales}
      });
    } else { // bar
      let labels, data;
      if (state.columnTypes[xCol] === "numeric" && !yCol){
        labels = rows.slice(0,30).map((r,i)=>i+1); data = rows.slice(0,30).map(r=>r[xCol]);
      } else if (yCol && state.columnTypes[yCol] === "numeric"){
        const agg = {};
        rows.forEach(r => { const k=String(r[xCol]); agg[k]=(agg[k]||0)+ (isNumericVal(r[yCol])?r[yCol]:0); });
        labels = Object.keys(agg).slice(0,25); data = labels.map(l=>agg[l]);
      } else {
        const freq = {};
        rows.forEach(r => { const k=String(r[xCol]); freq[k]=(freq[k]||0)+1; });
        labels = Object.keys(freq).slice(0,25); data = labels.map(l=>freq[l]);
      }
      state.charts.main = new Chart(canvas, {
        type:"bar",
        data:{ labels, datasets:[{ label: yCol ? `${yCol} by ${xCol}` : `Count of ${xCol}`, data, backgroundColor: hexAlpha(accent,0.8), borderRadius:4 }] },
        options: {...commonOpts, scales: commonScales}
      });
    }
  }

  $("#export-chart-btn").addEventListener("click", () => {
    if (!state.charts.main) return;
    const link = document.createElement("a");
    link.download = "dataclean-insights-chart.png";
    link.href = state.charts.main.toBase64Image();
    link.click();
  });

  /* =========================================================
     INSIGHTS MODULE
     ========================================================= */
  function renderInsightsEmptyToggle(hasData){
    $("#insights-empty").classList.toggle("hidden", hasData);
    $("#insights-content").classList.toggle("hidden", !hasData);
  }

  function runInsights(){
    const rows = currentRows(), cols = currentColumns();
    if (!rows.length){ renderInsightsEmptyToggle(false); return; }
    renderInsightsEmptyToggle(true);
    const numCols = numericColumns();
    const cards = [];

    cards.push(`Your cleaned dataset contains <strong>${rows.length.toLocaleString()}</strong> records across <strong>${cols.length}</strong> columns.`);
    cards.push(`During cleaning, <strong>${state.missingCount.toLocaleString()}</strong> missing values, <strong>${state.duplicateCount.toLocaleString()}</strong> duplicate rows and <strong>${state.outlierCount.toLocaleString()}</strong> outliers were identified in the original data.`);
    if (numCols.length){
      const c = numCols[0];
      const s = colStats(rows, c, "numeric");
      if (s) cards.push(`"${c}" ranges from ${fmtNum(s.min)} to ${fmtNum(s.max)}, averaging ${fmtNum(s.mean)} (median ${fmtNum(s.median)}).`);
    }
    const textCols = cols.filter(c => state.columnTypes[c] === "text");
    if (textCols.length){
      const c = textCols[0];
      const s = colStats(rows, c, "text");
      if (s) cards.push(`"${c}" has ${s.unique} unique values — the most common is "${s.mode}".`);
    }
    const completeness = 100 - (state.missingCount / (state.rawRows.length * state.rawColumns.length || 1) * 100);
    cards.push(`Original data completeness was approximately <strong>${completeness.toFixed(1)}%</strong> before cleaning.`);

    $("#insight-cards").innerHTML = cards.map(c => `<div class="insight-card">${c}</div>`).join("");
  }

  /* =========================================================
     DOWNLOAD / EXPORT
     ========================================================= */
  $("#download-cleaned-btn").addEventListener("click", () => {
    const rows = currentRows(), cols = currentColumns();
    if (!rows.length) return;
    const csv = Papa.unparse({ fields: cols, data: rows.map(r => cols.map(c => r[c])) });
    downloadBlob(csv, "cleaned_dataset.csv", "text/csv");
  });

  $("#download-report-btn").addEventListener("click", () => {
    const rows = currentRows(), cols = currentColumns();
    const chartImg = state.charts.main ? state.charts.main.toBase64Image() : "";
    const html = `<!DOCTYPE html><html><head><meta charset="utf-8"><title>DataClean Insights Report</title>
      <style>body{font-family:sans-serif;max-width:900px;margin:40px auto;color:#16202E}
      h1{font-family:sans-serif}table{border-collapse:collapse;width:100%;font-size:13px}
      td,th{border:1px solid #ddd;padding:6px 10px;text-align:left}</style></head><body>
      <h1>DataClean Insights — Report</h1>
      <p>Dataset: ${escapeHtml(state.fileName||"—")} · ${rows.length} rows × ${cols.length} columns</p>
      <p>Missing values: ${state.missingCount} · Duplicates: ${state.duplicateCount} · Outliers: ${state.outlierCount}</p>
      ${chartImg ? `<h2>Chart</h2><img src="${chartImg}" style="max-width:100%"/>` : ""}
      <h2>Insights</h2><ul>${$$(".insight-card").map(c=>`<li>${c.innerHTML}</li>`).join("")}</ul>
      </body></html>`;
    downloadBlob(html, "dataclean_insights_report.html", "text/html");
  });

  function downloadBlob(content, filename, type){
    const blob = new Blob([content], {type});
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = filename; a.click();
    URL.revokeObjectURL(url);
  }

})();
