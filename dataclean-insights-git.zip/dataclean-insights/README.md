# DataClean Insights

A modern, responsive, interactive **Data Cleaning & Visualization** web app.
Upload a raw CSV/Excel file, clean it, analyze it, and explore it through a
live dashboard — entirely in the browser, so it deploys as a static site on
**GitHub Pages** with no backend required.

**Pipeline:** Upload → Clean → Process → Analyze → Visualize

## Features

- **Landing page** — pipeline overview, "Get Started" entry point
- **Upload** — drag-and-drop or browse, CSV/XLSX/XLS, raw data preview, row/column/size summary
- **Data Cleaning** — missing-value handling (drop / mean / median / mode / fill), duplicate
  removal, IQR-based outlier detection, format normalization, column rename & remove, cleaning
  summary and cleaned-data preview
- **Data Analysis** — mean/median/mode/min/max/std per column, data-type detection, Pearson
  correlation heatmap, auto-generated key insights
- **Visualization Dashboard** — KPI cards (records, columns, missing, duplicates, outliers),
  selectable bar / line / pie / histogram / scatter charts with X/Y column pickers, dataset
  filtering, PNG chart export
- **Insights** — narrative takeaways generated from the cleaned dataset
- **Export** — download the cleaned dataset as CSV, or a visual report as HTML
- Sidebar navigation, light/dark mode, fully responsive (desktop + mobile)

## Tech stack

Runs 100% client-side:

| Layer         | Library |
|---------------|---------|
| Parsing       | [PapaParse](https://www.papaparse.com/) (CSV), [SheetJS/xlsx](https://sheetjs.com/) (Excel) |
| Processing    | Vanilla JavaScript (cleaning, stats, correlation) |
| Visualization | [Chart.js](https://www.chartjs.org/) |
| UI            | HTML5, CSS3 (no framework) |

No server, database, or build step needed — open `index.html` or host the
folder as-is.

### Optional Python backend

If you'd rather run the same pipeline server-side (e.g. for larger datasets
or a Streamlit/Flask course project), pair this front end's design with:

```
backend/
  app.py            # Flask routes or Streamlit script
  cleaning.py        # pandas/numpy cleaning functions
  analysis.py         # summary stats & correlation (pandas)
  charts.py            # matplotlib / seaborn / plotly figures
requirements.txt       # flask, pandas, numpy, matplotlib, seaborn, plotly
```

That version would POST the uploaded file to Flask, clean it with
Pandas/NumPy, and render charts with Matplotlib/Seaborn/Plotly — useful if
you need this to run as a Python assignment rather than a static site.

## Run locally

```bash
# from the project folder
python3 -m http.server 8000
# then open http://localhost:8000
```

## Deploy to GitHub Pages

1. Create a new GitHub repository and push this folder's contents to it:
   ```bash
   git init
   git add .
   git commit -m "Initial commit: DataClean Insights"
   git branch -M main
   git remote add origin https://github.com/<your-username>/<your-repo>.git
   git push -u origin main
   ```
2. In the repo, go to **Settings → Pages**.
3. Under **Build and deployment**, set **Source** to `Deploy from a branch`,
   branch `main`, folder `/ (root)`.
4. Save — your site will be live at
   `https://<your-username>.github.io/<your-repo>/` within a minute or two.

## Project structure

```
dataclean-insights/
├── index.html          # landing page + full app shell (all views)
├── css/
│   └── style.css        # design tokens, layout, components, responsiveness
├── js/
│   └── app.js            # parsing, cleaning, stats, charts, navigation
├── sample-data.csv        # small sample dataset for a quick demo
└── README.md
```

## Try it fast

Upload `sample-data.csv` (included) right after clicking **Get Started** —
it has a duplicate row, a few missing values, and a salary outlier baked in
so every cleaning/analysis feature has something to do immediately.

## Privacy

Every step — parsing, cleaning, statistics, charts — happens in your
browser's memory. No file you upload is ever sent to a server.
